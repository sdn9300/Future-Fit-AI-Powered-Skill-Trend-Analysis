

Create a Python module called `context_builder.py` that assembles the full prompt context for an email reply drafting agent.

It should have these functions:

1. `load_tone_profile(path="tone_profile.json")` → reads and returns the tone profile dict
2. `load_past_replies(path="past_replies.json")` → reads and returns list of past reply examples
3. `format_thread_history(thread)` → takes a thread dict with "subject" and "messages" (list of {from, date, body}) and formats it as a readable string showing who said what in order
4. `build_system_prompt(tone_profile, past_replies)` → builds the system prompt that includes:
   - The persona (name, role, tone, formality)
   - Writing rules from the quirks list
   - 2-3 past reply examples formatted as "Here's how {name} writes:"
5. `build_user_prompt(thread_formatted)` → builds the user message asking for a reply draft
6. `assemble_context(thread, tone_path="tone_profile.json", replies_path="past_replies.json")` → the main function that loads everything and returns a dict: {"system": system_prompt, "user": user_prompt}

Also create:
- `tone_profile.json` — a sample tone profile for a "Senior Product Manager" named Rahul who writes in a professional but warm tone, keeps emails short, uses dashes for asides, and signs off with "Best, Rahul"
- `past_replies.json` — 2-3 sample past emails showing this person's writing style (short, direct, friendly, uses numbered points)

Print the assembled prompt at the end so we can see it.
